class yes {
}