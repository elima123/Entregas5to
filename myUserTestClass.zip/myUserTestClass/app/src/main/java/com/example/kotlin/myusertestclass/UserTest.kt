package com.example.kotlin.myusertestclass
import org.junit.Assert.*
import org.junit.Test

// Create a User class and a UserTest class taking as a baseline the uploaded kt files.
// Create all the corresponding tests to the Methods.

class User(val name: String, val age: Int) {
    fun isAdult(): Boolean {
        return age >= 18
    }
}

class UserTest {

    @Test
    fun testIsAdult() {
        val user = User("John", 20)
        assertTrue(user.isAdult())
    }

    @Test
    fun testIsNotAdult() {
        val user = User("John", 15)
        assertFalse(user.isAdult())
    }

    @Test
    fun testGetName() {
        val user = User("John", 20)
        assertEquals("John", user.name)
    }

    @Test
    fun testGetAge() {
        val user = User("John", 20)
        assertEquals(20, user.age)
    }

}

